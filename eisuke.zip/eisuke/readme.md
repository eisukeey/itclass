##19-1-14 Updated##

スマホレスポンシブ対応
https://qiita.com/ymtm_jp/items/e8c55046429438a91903
cssなど
https://saruwakakun.com/
時計
https://xdsoft.net/jqplugins/flipcountdown/
背景ピンク
http://www.htmq.com/style/background.shtml
スライドショー
http://jonraasch.com/blog/a-simple-jquery-slideshow