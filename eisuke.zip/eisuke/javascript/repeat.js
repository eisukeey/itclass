 function kurikaeshi() {
            var n = 0;
            for (var n = 0; n < 8; n++) {
                if (n % 2 == 1)
                    alert(n)
            }
        }
